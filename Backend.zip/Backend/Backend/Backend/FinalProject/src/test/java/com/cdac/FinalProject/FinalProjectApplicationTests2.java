package com.cdac.FinalProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalProjectApplicationTests2 {

	@Test
	void contextLoads() {
	}

}
